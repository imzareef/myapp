# Update for WP-API v2

Now uses the WP-API v2 plugin instead of the Reactor Core plugin. Breaks compatibility with the WP-API v1.